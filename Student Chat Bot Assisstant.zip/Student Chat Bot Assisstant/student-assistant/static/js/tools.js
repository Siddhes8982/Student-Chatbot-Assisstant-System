(() => {
  const root = document.documentElement;
  const themeButton = document.getElementById('toolsTheme');
  const toast = document.getElementById('toolToast');
  let toastTimer;
  let latestText = '';

  const savedTheme = localStorage.getItem('studymate-theme');
  if (savedTheme === 'dark' || savedTheme === 'light') root.dataset.theme = savedTheme;
  updateThemeButton();
  if (window.marked) marked.setOptions({ gfm: true, breaks: true });

  themeButton.addEventListener('click', () => {
    root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('studymate-theme', root.dataset.theme);
    updateThemeButton();
  });

  function updateThemeButton() {
    const dark = root.dataset.theme === 'dark';
    themeButton.setAttribute('aria-label', `Switch to ${dark ? 'light' : 'dark'} theme`);
    themeButton.title = `Switch to ${dark ? 'light' : 'dark'} theme`;
    themeButton.innerHTML = `<i data-lucide="${dark ? 'sun' : 'moon'}"></i>`;
    document.querySelector('meta[name="theme-color"]').content = dark ? '#191b27' : '#f5f7fb';
    if (window.lucide) lucide.createIcons();
  }

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2200);
  }

  function renderMarkdown(target, text) {
    target.lang = /[\u0B80-\u0BFF]/.test(text) ? 'ta' : 'en';
    if (!window.marked || !window.DOMPurify) {
      target.textContent = text;
      return;
    }
    target.innerHTML = DOMPurify.sanitize(marked.parse(text));
    if (window.hljs) target.querySelectorAll('pre code').forEach(code => hljs.highlightElement(code));
  }

  function loadingContent(result) {
    result.hidden = false;
    result.querySelector('.tool-error')?.remove();
    if (!result.querySelector('.tool-loading')) {
      const loading = document.createElement('div');
      loading.className = 'tool-loading';
      loading.innerHTML = '<span class="tool-loading-dots"><i></i><i></i><i></i></span><span>Asking local Llama 3.2 to work through this…</span>';
      result.append(loading);
    }
  }

  function showError(result, message) {
    result.hidden = false;
    result.querySelector('.tool-loading')?.remove();
    result.querySelector('.tool-error')?.remove();
    const error = document.createElement('div');
    error.className = 'tool-error';
    error.textContent = message || 'The tool could not generate a response. Please try again.';
    result.append(error);
  }

  function getCsrfToken() {
    return document.querySelector('meta[name="csrf-token"]')?.content || '';
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      showToast('Copied to clipboard.');
    } catch (_) {
      showToast('Clipboard access is unavailable in this browser.');
    }
  }

  function renderQuiz(result, quiz) {
    const questions = quiz.questions;
    const title = document.getElementById('quizTitle');
    const progress = document.getElementById('quizProgress');
    const content = document.getElementById('quizContent');
    const state = { index: 0, score: 0, selected: null, checked: false };
    title.textContent = `${questions.length} questions`;

    function finish() {
      progress.textContent = 'Complete';
      const percent = Math.round((state.score / questions.length) * 100);
      const panel = document.createElement('div'); panel.className = 'quiz-final';
      const ring = document.createElement('div'); ring.className = 'score-ring'; ring.textContent = `${percent}%`;
      const heading = document.createElement('h3'); heading.textContent = `You scored ${state.score} of ${questions.length}`;
      const note = document.createElement('p');
      note.textContent = percent === 100 ? 'Excellent work. You have this topic down.' : percent >= 60 ? 'Good progress. Review the explanations to strengthen what you know.' : 'Keep practicing. Use the explanations to review each idea.';
      const retry = document.createElement('button'); retry.className = 'primary'; retry.type = 'button'; retry.textContent = 'Try this quiz again';
      retry.addEventListener('click', () => { state.index = 0; state.score = 0; state.selected = null; state.checked = false; renderQuestion(); });
      panel.append(ring, heading, note, retry); content.replaceChildren(panel);
    }

    function renderQuestion() {
      if (state.index >= questions.length) { finish(); return; }
      const question = questions[state.index];
      state.selected = null; state.checked = false;
      progress.textContent = `Question ${state.index + 1} of ${questions.length}`;
      content.replaceChildren();
      const prompt = document.createElement('h3'); prompt.className = 'quiz-question'; prompt.textContent = question.question;
      const options = document.createElement('div'); options.className = 'quiz-option-list';
      const feedback = document.createElement('div'); feedback.className = 'quiz-feedback'; feedback.hidden = true;
      const controls = document.createElement('div'); controls.className = 'quiz-controls';
      const check = document.createElement('button'); check.className = 'primary'; check.type = 'button'; check.textContent = 'Check answer'; check.disabled = true;
      const next = document.createElement('button'); next.type = 'button'; next.textContent = state.index + 1 === questions.length ? 'See score' : 'Next question'; next.hidden = true;

      for (const option of question.options) {
        const button = document.createElement('button'); button.type = 'button'; button.className = 'quiz-option';
        const letter = document.createElement('span'); letter.className = 'option-letter'; letter.textContent = option.label;
        const label = document.createElement('span'); label.textContent = option.text;
        button.append(letter, label);
        button.addEventListener('click', () => {
          if (state.checked) return;
          state.selected = option.label;
          options.querySelectorAll('.quiz-option').forEach(item => item.classList.remove('selected'));
          button.classList.add('selected'); check.disabled = false;
        });
        options.append(button);
      }

      check.addEventListener('click', () => {
        if (!state.selected || state.checked) return;
        state.checked = true;
        const correct = state.selected === question.correct_answer;
        if (correct) state.score += 1;
        options.querySelectorAll('.quiz-option').forEach(button => {
          const label = button.querySelector('.option-letter').textContent;
          button.disabled = true;
          if (label === question.correct_answer) button.classList.add('correct');
          else if (label === state.selected) button.classList.add('incorrect');
        });
        const correctOption = question.options.find(option => option.label === question.correct_answer);
        const outcome = document.createElement('strong');
        outcome.textContent = correct ? 'That’s right!' : `The correct answer is ${question.correct_answer}: ${correctOption?.text || ''}`;
        const explanation = document.createElement('span'); explanation.textContent = question.explanation;
        feedback.replaceChildren(outcome, explanation); feedback.hidden = false;
        check.hidden = true; next.hidden = false;
      });
      next.addEventListener('click', () => { state.index += 1; renderQuestion(); });
      controls.append(check, next);
      content.append(prompt, options, feedback, controls);
    }

    renderQuestion();
  }

  document.querySelectorAll('form.tool-form[data-tool]').forEach(form => form.addEventListener('submit', async event => {
    event.preventDefault();
    if (form.dataset.submitting === 'true') return;
    form.dataset.submitting = 'true';
    const tool = form.dataset.tool;
    const result = document.getElementById('toolResult');
    const submit = form.querySelector('[type="submit"]');
    const body = Object.fromEntries(new FormData(form).entries());
    if (body.count) body.count = Number(body.count);
    if (body.practice_count) body.practice_count = Number(body.practice_count);
    submit.disabled = true;
    loadingContent(result);
    try {
      const response = await fetch(`/api/tools/${tool}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': getCsrfToken() },
        body: JSON.stringify(body),
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || 'The tool could not generate a response.');
      result.querySelector('.tool-loading')?.remove();
      if (tool === 'quiz') {
        renderQuiz(result, payload);
      } else if (tool === 'assignment') {
        const draft = document.getElementById('editableDraft');
        const preview = document.getElementById('assignmentPreview');
        draft.value = payload.content;
        latestText = payload.content;
        renderMarkdown(preview, draft.value);
        draft.oninput = () => { latestText = draft.value; renderMarkdown(preview, draft.value); };
        result.hidden = false;
        result.querySelector('[data-copy-assignment]').onclick = () => copyText(draft.value);
      } else {
        latestText = payload.content;
        result.hidden = false;
        renderMarkdown(document.getElementById('markdownResult'), payload.content);
        const copy = result.querySelector('[data-copy-result]');
        if (copy) copy.onclick = () => copyText(latestText);
      }
      result.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (error) {
      showError(result, error.message);
    } finally {
      form.dataset.submitting = 'false';
      submit.disabled = false;
    }
  }));

  if (window.lucide) lucide.createIcons();
})();
