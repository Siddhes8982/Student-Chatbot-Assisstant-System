document.querySelectorAll('[data-password-toggle]').forEach(button => {
  button.addEventListener('click', () => {
    const input = document.getElementById(button.dataset.passwordToggle);
    const showing = input.type === 'password';
    input.type = showing ? 'text' : 'password';
    button.setAttribute('aria-label', showing ? 'Hide password' : 'Show password');
    button.innerHTML = `<i data-lucide="${showing ? 'eye-off' : 'eye'}"></i>`;
    if (window.lucide) lucide.createIcons();
  });
});
