(() => {
  const root = document.documentElement;
  const themeToggle = document.getElementById('themeToggle');
  const themeIcon = document.getElementById('themeIcon');
  const sidebar = document.getElementById('sidebar');
  const scrim = document.getElementById('sidebarScrim');
  const conversationView = document.getElementById('conversation');
  const welcome = document.getElementById('welcomeView');
  const messageList = document.getElementById('messageList');
  const input = document.getElementById('messageInput');
  const sendButton = document.getElementById('sendButton');
  const form = document.getElementById('composerForm');
  const title = document.getElementById('pageTitle');
  const toast = document.getElementById('toast');
  const clearButton = document.getElementById('clearChat');
  const historyList = document.getElementById('historyList');
  let currentConversationId = null;
  let activeGeneration = null;
  let toastTimer;
  let renderFrame = 0;

  const savedTheme = localStorage.getItem('studymate-theme');
  if (savedTheme === 'dark' || savedTheme === 'light') root.dataset.theme = savedTheme;
  updateThemeButton();
  if (window.marked) marked.setOptions({ gfm: true, breaks: true });
  if (window.lucide) lucide.createIcons();

  themeToggle.addEventListener('click', () => {
    root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('studymate-theme', root.dataset.theme);
    updateThemeButton();
  });

  function updateThemeButton() {
    const dark = root.dataset.theme === 'dark';
    themeToggle.setAttribute('aria-label', `Switch to ${dark ? 'light' : 'dark'} theme`);
    themeToggle.title = `Switch to ${dark ? 'light' : 'dark'} theme`;
    themeIcon.setAttribute('data-lucide', dark ? 'sun' : 'moon');
    if (window.lucide) lucide.createIcons();
    document.querySelector('meta[name="theme-color"]').content = dark ? '#191b27' : '#f5f7fb';
  }

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2400);
  }

  function closeSidebar() { sidebar.classList.remove('open'); scrim.classList.remove('visible'); }
  document.getElementById('menuButton').addEventListener('click', () => { sidebar.classList.add('open'); scrim.classList.add('visible'); });
  document.getElementById('sidebarClose').addEventListener('click', closeSidebar);
  scrim.addEventListener('click', closeSidebar);

  function setBusy(busy) {
    sendButton.disabled = busy ? false : !input.value.trim();
    sendButton.setAttribute('aria-label', busy ? 'Stop generation' : 'Send message');
    sendButton.title = busy ? 'Stop generation' : 'Send message';
    sendButton.innerHTML = busy ? '<i data-lucide="square"></i>' : '<i data-lucide="arrow-up"></i>';
    if (window.lucide) lucide.createIcons();
    clearButton.disabled = !currentConversationId || busy;
    input.disabled = busy;
  }

  function resizeInput() {
    input.style.height = 'auto';
    input.style.height = `${Math.min(input.scrollHeight, 130)}px`;
  }
  function updateSendButton() {
    if (!activeGeneration) sendButton.disabled = !input.value.trim();
  }
  input.addEventListener('input', () => { resizeInput(); updateSendButton(); });
  input.addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      if (activeGeneration) stopGeneration();
      else if (input.value.trim()) form.requestSubmit();
    }
  });

  function setConversationView(hasMessages) {
    welcome.hidden = hasMessages;
    messageList.hidden = !hasMessages;
    clearButton.disabled = !currentConversationId || Boolean(activeGeneration);
    if (!hasMessages) title.textContent = 'New conversation';
  }

  function resetChat() {
    if (activeGeneration) discardGeneration();
    currentConversationId = null;
    messageList.replaceChildren();
    setConversationView(false);
    input.value = '';
    input.disabled = false;
    resizeInput(); updateSendButton(); closeSidebar();
    document.querySelectorAll('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.panel === 'chat'));
    document.querySelectorAll('.history-link').forEach(item => item.classList.remove('selected'));
    input.focus({ preventScroll: true });
    renderHistory();
  }
  document.getElementById('newChat').addEventListener('click', resetChat);

  document.querySelectorAll('.nav-item').forEach(item => item.addEventListener('click', () => {
    const panel = item.dataset.panel;
    if (panel === 'chat') { resetChat(); return; }
    document.querySelectorAll('.nav-item').forEach(nav => nav.classList.toggle('active', nav === item));
    if (panel === 'history') {
      historyList.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      if (!historyList.children.length) showToast('Your saved conversations will appear here.');
    } else if (panel === 'settings') window.location.href = '/profile#language-settings';
    else showToast('Academic tools are coming soon.');
    closeSidebar();
  }));

  document.getElementById('attachButton').addEventListener('click', () => showToast('File attachments are coming soon.'));

  document.querySelectorAll('.prompt-card').forEach(card => card.addEventListener('click', () => {
    input.value = card.dataset.prompt;
    resizeInput(); updateSendButton(); input.focus();
  }));

  function renderMarkdown(raw, target) {
    target.lang = /[\u0B80-\u0BFF]/.test(raw) ? 'ta' : 'en';
    if (!window.marked || !window.DOMPurify) {
      target.textContent = raw;
      return;
    }
    target.innerHTML = DOMPurify.sanitize(marked.parse(raw));
    if (window.hljs) target.querySelectorAll('pre code').forEach(block => hljs.highlightElement(block));
  }

  function scheduleScroll() {
    if (renderFrame) cancelAnimationFrame(renderFrame);
    renderFrame = requestAnimationFrame(() => {
      conversationView.scrollTop = conversationView.scrollHeight;
      renderFrame = 0;
    });
  }

  function addUserMessage(text) {
    const row = document.createElement('div'); row.className = 'message-row user-row';
    const bubble = document.createElement('div'); bubble.className = 'message-bubble'; bubble.lang = /[\u0B80-\u0BFF]/.test(text) ? 'ta' : 'en'; bubble.textContent = text;
    const avatar = document.createElement('div'); avatar.className = 'profile-avatar message-user-avatar'; avatar.textContent = 'S';
    row.append(bubble, avatar); messageList.append(row); scheduleScroll();
  }

  function addAssistantMessage(raw = '', options = {}) {
    const row = document.createElement('div'); row.className = 'message-row assistant-message';
    const avatar = document.createElement('div'); avatar.className = 'message-avatar'; avatar.innerHTML = '<i data-lucide="sparkles"></i>';
    const bubble = document.createElement('div'); bubble.className = 'message-bubble';
    const content = document.createElement('div'); content.className = 'message-content';
    bubble.append(content);
    const actions = document.createElement('div'); actions.className = 'message-actions';
    const copy = document.createElement('button'); copy.className = 'message-action'; copy.type = 'button';
    copy.innerHTML = '<i data-lucide="copy"></i><span>Copy</span>';
    copy.addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(raw); showToast('Copied to clipboard.'); }
      catch (_) { showToast('Clipboard access is unavailable in this browser.'); }
    });
    actions.append(copy);
    row.append(avatar, bubble, actions);
    messageList.append(row);
    if (window.lucide) lucide.createIcons({ nodes: [row] });
    scheduleScroll();
    if (options.loading) {
      row.classList.add('generating');
      content.innerHTML = '<span class="loading-dots" aria-label="StudyMate is thinking"><span></span><span></span><span></span></span>';
    } else renderMarkdown(raw, content);
    return { row, content, actions, copy, setRaw(value) { raw = value; renderMarkdown(raw, content); scheduleScroll(); }, getRaw() { return raw; } };
  }

  function addGenerationError(message) {
    const note = document.createElement('p'); note.className = 'message-error'; note.textContent = message;
    messageList.append(note); scheduleScroll();
  }

  function addStoppedNote() {
    const note = document.createElement('p'); note.className = 'message-stopped'; note.textContent = 'Generation stopped. You can regenerate this answer or continue the conversation.';
    messageList.append(note);
  }

  function addRegenerateAction(assistant, conversationId) {
    const button = document.createElement('button'); button.type = 'button'; button.className = 'message-action';
    button.innerHTML = '<i data-lucide="rotate-cw"></i><span>Regenerate</span>';
    button.addEventListener('click', () => sendMessage('', { regenerate: true, conversationId, replaceRow: assistant.row }));
    assistant.actions.append(button);
    if (window.lucide) lucide.createIcons({ nodes: [button] });
  }

  async function readSse(response, onEvent) {
    if (!response.ok) {
      let message = `Request failed (${response.status}).`;
      try { message = (await response.json()).error || message; } catch (_) { /* keep status */ }
      throw new Error(message);
    }
    if (!response.body) throw new Error('Streaming is unavailable in this browser.');
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let finished = false;
    while (!finished) {
      const { value, done } = await reader.read();
      buffer += decoder.decode(value || new Uint8Array(), { stream: !done });
      let boundary;
      while ((boundary = buffer.indexOf('\n\n')) >= 0) {
        const block = buffer.slice(0, boundary); buffer = buffer.slice(boundary + 2);
        const eventName = (block.match(/^event:\s*(.+)$/m) || [])[1] || 'message';
        const data = (block.match(/^data:\s*(.*)$/m) || [])[1];
        if (data) onEvent(eventName, JSON.parse(data));
      }
      finished = done;
    }
  }

  async function sendMessage(text, options = {}) {
    if (activeGeneration) return;
    const regenerate = Boolean(options.regenerate);
    const conversationId = options.conversationId ?? currentConversationId;
    if (!regenerate && !text.trim()) return;
    if (options.replaceRow) options.replaceRow.remove();
    if (!regenerate) addUserMessage(text);
    setConversationView(true);
    if (!regenerate) title.textContent = text.length > 30 ? `${text.slice(0, 30)}…` : text;
    const assistant = addAssistantMessage('', { loading: true });
    const controller = new AbortController();
    const generation = { controller, assistant, raw: '', hasDone: false, discarded: false };
    activeGeneration = generation;
    setBusy(true);
    closeSidebar();

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'text/event-stream', 'X-CSRF-Token': csrfToken() },
        body: JSON.stringify({ conversation_id: conversationId, message: text, regenerate }),
        signal: controller.signal,
      });
      await readSse(response, (eventName, payload) => {
        if (generation.discarded || activeGeneration !== generation) return;
        if (eventName === 'meta') {
          currentConversationId = payload.conversation_id;
          clearButton.disabled = true;
          renderHistory();
        } else if (eventName === 'token') {
          activeGeneration.raw += payload.content || '';
          assistant.row.classList.remove('generating');
          assistant.setRaw(activeGeneration.raw);
        } else if (eventName === 'done') {
          activeGeneration.hasDone = true;
          assistant.row.classList.remove('generating');
          assistant.setRaw(payload.message.content || activeGeneration.raw);
          addRegenerateAction(assistant, currentConversationId);
        } else if (eventName === 'error') {
          activeGeneration.hasError = true;
          assistant.row.remove();
          addGenerationError(payload.message || 'The response could not be generated.');
        }
      });
      if (!generation.discarded && !generation.hasDone && !generation.hasError && generation.raw) addStoppedNote();
    } catch (error) {
      if (!generation.discarded) {
        if (error.name === 'AbortError') {
          assistant.row.classList.remove('generating');
          if (!assistant.getRaw()) assistant.row.remove();
          else addStoppedNote();
        } else {
          assistant.row.remove();
          addGenerationError(error.message || 'Could not reach StudyMate. Please try again.');
        }
      }
    } finally {
      if (activeGeneration === generation) {
        activeGeneration = null;
        input.disabled = false;
        setBusy(false);
        resizeInput(); updateSendButton();
        input.focus({ preventScroll: true });
      }
      await renderHistory();
    }
  }

  function stopGeneration() {
    if (!activeGeneration) return;
    activeGeneration.controller.abort();
    sendButton.disabled = true;
  }

  function discardGeneration() {
    if (!activeGeneration) return;
    activeGeneration.discarded = true;
    activeGeneration.controller.abort();
    activeGeneration = null;
    input.disabled = false;
    setBusy(false);
  }

  form.addEventListener('submit', event => {
    event.preventDefault();
    if (activeGeneration) { stopGeneration(); return; }
    const text = input.value.trim();
    if (!text) return;
    input.value = ''; resizeInput(); updateSendButton();
    sendMessage(text);
  });
  sendButton.addEventListener('click', () => { if (activeGeneration) stopGeneration(); });

  document.getElementById('newChat').addEventListener('click', () => {
    if (activeGeneration) discardGeneration();
  }, { capture: true });

  clearButton.addEventListener('click', async () => {
    if (!currentConversationId || activeGeneration) return;
    try {
      const response = await fetch(`/api/conversations/${currentConversationId}/messages`, {
        method: 'DELETE', headers: { 'X-CSRF-Token': csrfToken() },
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Could not clear this conversation.');
      messageList.replaceChildren(); setConversationView(false); await renderHistory(); showToast('Conversation cleared.');
    } catch (error) { showToast(error.message); }
  });

  async function openConversation(id) {
    if (activeGeneration) discardGeneration();
    try {
      const response = await fetch(`/api/conversations/${id}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not open conversation.');
      currentConversationId = id;
      title.textContent = data.conversation.title;
      messageList.replaceChildren();
      setConversationView(data.messages.length > 0);
      let lastAssistant = null;
      for (const message of data.messages) {
        if (message.role === 'user') addUserMessage(message.content);
        else if (message.role === 'assistant' && message.content) {
          const rendered = addAssistantMessage(message.content);
          if (!message.is_complete) addStoppedNote();
          lastAssistant = { ...rendered, id: message.id };
        }
      }
      if (lastAssistant && data.messages.at(-1)?.role === 'assistant') addRegenerateAction(lastAssistant, id);
      clearButton.disabled = false;
      document.querySelectorAll('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.panel === 'history'));
      await renderHistory(); closeSidebar(); scheduleScroll();
    } catch (error) { showToast(error.message); }
  }

  async function renderHistory() {
    try {
      const response = await fetch('/api/conversations', { cache: 'no-store' });
      if (!response.ok) return;
      const { conversations } = await response.json();
      historyList.replaceChildren();
      document.querySelectorAll('.nav-count').forEach(el => { el.textContent = String(conversations.length); });
      if (!conversations.length) {
        const empty = document.createElement('div'); empty.className = 'history-empty'; empty.textContent = 'Your conversations will show up here.';
        historyList.append(empty);
      } else {
        for (const item of conversations.slice(0, 8)) {
          const button = document.createElement('button'); button.type = 'button'; button.className = 'history-link';
          button.textContent = item.title || 'New conversation'; button.title = item.title || 'New conversation';
          button.classList.toggle('selected', item.id === currentConversationId);
          button.addEventListener('click', () => openConversation(item.id)); historyList.append(button);
        }
      }
    } catch (_) { /* History remains usable when the server is temporarily unavailable. */ }
  }

  document.getElementById('attachButton').addEventListener('click', () => showToast('File attachments are coming soon.'));
  document.querySelectorAll('.prompt-card').forEach(card => card.addEventListener('click', () => {
    input.value = card.dataset.prompt; resizeInput(); updateSendButton(); input.focus();
  }));

  async function checkOllama() {
    const pill = document.getElementById('connectionPill');
    const label = document.getElementById('connectionLabel');
    try {
      const response = await fetch('/api/health', { cache: 'no-store' });
      const result = await response.json();
      const ready = response.ok && result.ollama?.running && result.ollama?.model_available;
      pill.classList.toggle('connected', Boolean(ready)); pill.classList.toggle('offline', !ready);
      label.textContent = ready ? 'Ollama connected' : 'Ollama offline';
      pill.title = result.ollama?.message || (ready ? 'Local Ollama is ready' : 'Ollama is unavailable');
    } catch (_) {
      pill.classList.add('offline'); label.textContent = 'Ollama offline'; pill.title = 'Could not check the local Ollama connection';
    }
  }

  function csrfToken() {
    return document.querySelector('meta[name="csrf-token"]')?.content || '';
  }

  document.addEventListener('keydown', event => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); resetChat(); }
    if (event.key === 'Escape') closeSidebar();
  });
  checkOllama();
  renderHistory();
  const requestedConversation = Number(new URLSearchParams(window.location.search).get('conversation'));
  if (Number.isSafeInteger(requestedConversation) && requestedConversation > 0) openConversation(requestedConversation);
})();
