"""SQLAlchemy extension and database initialization helpers."""

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import inspect, text

db = SQLAlchemy()


def init_db(app):
    """Create tables for all registered models within the app context."""
    with app.app_context():
        # Import models so SQLAlchemy knows about their tables.
        import models  # noqa: F401

        db.create_all()
        # create_all does not alter existing tables. Add the ownership column
        # to databases created before account support; legacy rows stay unowned
        # and are deliberately inaccessible through authenticated APIs.
        inspector = inspect(db.engine)
        if db.engine.dialect.name == "sqlite" and "users" in inspector.get_table_names():
            user_columns = {column["name"] for column in inspector.get_columns("users")}
            if "language_preference" not in user_columns:
                with db.engine.begin() as connection:
                    connection.execute(text(
                        "ALTER TABLE users ADD COLUMN language_preference VARCHAR(12) "
                        "NOT NULL DEFAULT 'auto'"
                    ))
        if db.engine.dialect.name == "sqlite" and "conversations" in inspector.get_table_names():
            columns = {column["name"] for column in inspector.get_columns("conversations")}
            if "user_id" not in columns:
                with db.engine.begin() as connection:
                    connection.execute(text(
                        "ALTER TABLE conversations ADD COLUMN user_id INTEGER "
                        "REFERENCES users(id) ON DELETE CASCADE"
                    ))
                    connection.execute(text(
                        "CREATE INDEX IF NOT EXISTS ix_conversations_user_id "
                        "ON conversations (user_id)"
                    ))
