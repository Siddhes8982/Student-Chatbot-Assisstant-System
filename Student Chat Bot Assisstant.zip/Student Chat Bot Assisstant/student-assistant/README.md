# StudyMate AI

StudyMate AI is a local student assistant built with Flask, SQLite, and Ollama's `llama3.2` model. It includes student accounts, private chat history, academic generation tools, a study planner, and local PDF question answering. Chat, tools, planner generation, and PDF answers use the configured local Ollama server. Uploaded PDF files and their indexes are stored under the application instance directory.

## Requirements

- Windows 10 or 11
- Python 3.11 or 3.12 (the project was audited with Python 3.12)
- Ollama for Windows
- Enough disk space for the Llama 3.2 model and the local sentence embedding model used by PDF search

## Windows installation

1. Install Python from [python.org](https://www.python.org/downloads/windows/). During setup, enable **Add Python to PATH**.
2. Install Ollama using the official [Windows download](https://ollama.com/download/windows). Ollama may start in the background after installation.
3. Open PowerShell and move to the project folder:

   ```powershell
   cd "C:\path\to\Student Chat Bot Assisstant\student-assistant"
   ```

4. Create and activate a virtual environment, then install the dependencies:

   ```powershell
   py -3.12 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

   If PowerShell blocks virtual environment activation, run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` once, then activate the environment again.

5. Create `.env` from the example and set a persistent session secret:

   ```powershell
   Copy-Item .env.example .env
   python -c "import secrets; print(secrets.token_urlsafe(48))"
   ```

   Copy the generated value into `.env` as `SECRET_KEY=...`. Keep `.env` private; it is excluded from version control.

## Install and start Llama 3.2

Open a second PowerShell window and run:

```powershell
ollama serve
ollama pull llama3.2
```

Keep Ollama running. If the Ollama desktop app has already started its server, `ollama serve` may say that the port is in use; in that case, use the running Ollama service and still run `ollama pull llama3.2`.

Check the installed model with:

```powershell
ollama list
```

The application defaults to `http://localhost:11434` and model `llama3.2`. Optional overrides are documented in `.env.example`.

## Initialize the database and run StudyMate

From the project folder, with the virtual environment active:

```powershell
python app.py
```

Flask creates the SQLite database and tables automatically on startup. The default database is `studymate.db` in this folder. Existing databases receive the included ownership and language preference migrations during startup. Keep a backup before manually changing or removing an existing database.

Open [http://127.0.0.1:5000](http://127.0.0.1:5000). The development server binds to localhost. Create a student account to use chat, academic tools, the planner, and PDF study features.

The health endpoint is public and reports Ollama and model availability:

```text
http://127.0.0.1:5000/api/health
```

## PDF study and local data

The first PDF upload may need to download the configured Sentence Transformers embedding model if it is not cached yet. Embedding and vector search run locally. The PDF text, indexes, and extracted passages are kept under `instance/rag` by default; retrieved passages are sent to the local Ollama API on this device. Scanned PDFs without selectable text need OCR before upload. PDF files are limited to 15 MB.

Set `RAG_STORAGE_DIR` in `.env` to move PDF storage to another local folder. Restrict access to that folder to the Windows account running StudyMate. Back up the SQLite database and `instance/rag` together if you need to preserve the PDF library.

## Troubleshooting

### Ollama is offline

- Confirm the Ollama application or `ollama serve` is running.
- Open `http://localhost:11434/api/tags` or run `ollama list`.
- Check that `OLLAMA_BASE_URL` in `.env` is `http://localhost:11434`.

### The model is missing

Run `ollama pull llama3.2`, then refresh the StudyMate page or `/api/health`. The health response includes the exact model download command when it is missing.

### A request takes a long time or times out

Local inference time depends on available memory, processor/GPU, model load state, and response size. The default Ollama request timeout is 120 seconds. A first request may take longer while the model loads. Set `OLLAMA_TIMEOUT_SECONDS` in `.env` to a larger number if needed, then restart Flask.

### Port 5000 is already in use

Stop the other local application using port 5000, then run `python app.py` again. StudyMate's documented URL is `http://127.0.0.1:5000`.

### PDF upload or retrieval fails

- Upload a PDF with selectable text and keep it under 15 MB.
- Allow the first-use embedding model download to finish; it is cached locally for later use.
- Check that the Windows account can write to `instance/rag` (or the configured `RAG_STORAGE_DIR`).
- Review the Flask terminal output for the local processing error.

### PowerShell cannot find Python or Ollama

Close and reopen PowerShell after installing either program. Check `py --version`, `python --version`, and `ollama --version`.

## Security and current limitations

- Passwords are stored as Werkzeug password hashes. Private pages and APIs require a student session, and chat, planner, and PDF records are scoped to the signed-in student.
- State-changing requests use a session CSRF token. Session cookies are HTTP-only and use `SameSite=Lax`; set `SESSION_COOKIE_SECURE=true` only when serving the application over HTTPS.
- Keep the Flask development server on localhost. It is not a production deployment server.
- Tamil output is supported by the installed model, but `llama3.2` may produce inaccurate translations or academic explanations in Tamil. Verify important facts and translations with course materials.
- PDF question answering can only ground answers in selectable text extracted from uploaded PDFs. It does not perform OCR on scanned pages.
- The current page templates load Lucide icons and web fonts from CDNs. They may be unavailable without internet access; the app's local API and inference do not depend on those services.

## Project structure

```text
student-assistant/
  app.py
  config.py
  database.py
  models.py
  routes/       Flask page and API blueprints
  services/     Ollama, authentication, language, and RAG services
  templates/    Flask/Jinja pages
  static/       CSS, JavaScript, and icons
  instance/     Local SQLite support files and private PDF indexes
```
