"""Flask application entry point for StudyMate AI."""

import hmac
import secrets

from flask import Flask, g, jsonify, redirect, render_template, request, session, url_for

from config import Config
from database import db, init_db
from routes.health import health_bp
from routes.chat import chat_bp
from routes.auth import auth_bp
from routes.tools import tools_bp
from routes.planner import planner_bp
from routes.rag import rag_bp
from services.auth import login_required
from models import User
from services.ollama_service import OllamaError


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    db.init_app(app)
    app.register_blueprint(health_bp)
    app.register_blueprint(chat_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(tools_bp)
    app.register_blueprint(planner_bp)
    app.register_blueprint(rag_bp)
    init_db(app)

    @app.before_request
    def load_user_and_check_csrf():
        user_id = session.get("user_id")
        g.current_user = db.session.get(User, user_id) if isinstance(user_id, int) else None
        if user_id is not None and g.current_user is None:
            session.clear()

        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            if request.path.startswith("/api/") and g.current_user is None:
                return jsonify({"error": "Sign in to continue."}), 401
            expected = session.get("_csrf_token", "")
            supplied = request.headers.get("X-CSRF-Token") or request.form.get("csrf_token", "")
            if not expected or not supplied or not hmac.compare_digest(expected, supplied):
                message = "Your session token is missing or expired. Reload the page and try again."
                if request.path.startswith("/api/"):
                    return jsonify({"error": message}), 400
                return message, 400

    def csrf_token():
        token = session.get("_csrf_token")
        if token is None:
            token = secrets.token_urlsafe(32)
            session["_csrf_token"] = token
        return token

    @app.context_processor
    def inject_template_context():
        return {"current_user": g.get("current_user"), "csrf_token": csrf_token}

    @app.get("/")
    @login_required
    def index():
        return render_template("index.html")

    @app.errorhandler(OllamaError)
    def handle_ollama_error(error):
        return jsonify({"error": str(error)}), 503

    @app.errorhandler(401)
    def handle_unauthorized(_error):
        if request.path.startswith("/api/"):
            return jsonify({"error": "Sign in to continue."}), 401
        return redirect(url_for("auth.login"))

    @app.errorhandler(413)
    def handle_too_large(_error):
        message = "The request is too large. PDF uploads are limited to 15 MB."
        if request.path.startswith("/api/"):
            return jsonify({"error": message}), 413
        return message, 413

    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=app.config.get("DEBUG", False))
