"""Persistent conversations and streaming chat API."""

import json
from datetime import datetime, timezone

from flask import Blueprint, Response, current_app, g, jsonify, request, stream_with_context

from database import db
from models import Conversation, Message
from services.ollama_service import OllamaError, OllamaService
from services.auth import login_required
from services.language import detect_language, explicit_language_target, response_language_instruction, TAMIL_RE

chat_bp = Blueprint("chat", __name__)

SYSTEM_PROMPT = """You are StudyMate AI, an intelligent academic assistant for school and college students.

Your responsibilities:

- Explain academic concepts.
- Answer subject-related questions.
- Help students learn programming.
- Solve mathematical problems step by step.
- Prepare examination notes.
- Generate practice questions.
- Explain difficult topics in simple language.
- Support English and Tamil communication.

Always provide clear, accurate and structured answers.

Never invent information. If you are unsure, explain the uncertainty.

Act as a friendly teacher who helps students understand rather than simply providing answers."""


def _event(name, payload):
    return f"event: {name}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"


def _ollama():
    return OllamaService(
        current_app.config["OLLAMA_BASE_URL"],
        current_app.config["OLLAMA_MODEL"],
        current_app.config["OLLAMA_TIMEOUT_SECONDS"],
    )


@chat_bp.get("/api/conversations")
@login_required
def list_conversations():
    conversations = Conversation.query.filter_by(user_id=g.current_user.id).order_by(
        Conversation.updated_at.desc()
    ).all()
    return jsonify({"conversations": [item.to_dict() for item in conversations]})


@chat_bp.get("/api/conversations/<int:conversation_id>")
@login_required
def get_conversation(conversation_id):
    conversation = Conversation.query.filter_by(
        id=conversation_id, user_id=g.current_user.id
    ).first()
    if conversation is None:
        return jsonify({"error": "Conversation not found."}), 404
    messages = Message.query.filter_by(conversation_id=conversation.id).order_by(
        Message.created_at, Message.id
    ).all()
    return jsonify({"conversation": conversation.to_dict(), "messages": [item.to_dict() for item in messages]})


@chat_bp.delete("/api/conversations/<int:conversation_id>/messages")
@login_required
def clear_conversation(conversation_id):
    conversation = Conversation.query.filter_by(
        id=conversation_id, user_id=g.current_user.id
    ).first()
    if conversation is None:
        return jsonify({"error": "Conversation not found."}), 404
    Message.query.filter_by(conversation_id=conversation.id).delete(synchronize_session=False)
    conversation.title = "New conversation"
    conversation.updated_at = datetime.now(timezone.utc)
    db.session.commit()
    return jsonify({"conversation": conversation.to_dict(), "messages": []})


@chat_bp.delete("/api/conversations/<int:conversation_id>")
@login_required
def delete_conversation(conversation_id):
    conversation = Conversation.query.filter_by(
        id=conversation_id, user_id=g.current_user.id
    ).first()
    if conversation is None:
        return jsonify({"error": "Conversation not found."}), 404
    db.session.delete(conversation)
    db.session.commit()
    return jsonify({"deleted": True, "conversation_id": conversation_id})


@chat_bp.post("/api/chat")
@login_required
def chat():
    data = request.get_json(silent=True) or {}
    regenerate = data.get("regenerate") is True
    message_text = data.get("message")
    if not regenerate and (not isinstance(message_text, str) or not message_text.strip()):
        return jsonify({"error": "Enter a message to start chatting."}), 400
    if isinstance(message_text, str) and len(message_text) > 12000:
        return jsonify({"error": "Messages must be 12,000 characters or fewer."}), 413

    conversation_id = data.get("conversation_id")
    if conversation_id is not None and (
        isinstance(conversation_id, bool) or not isinstance(conversation_id, int) or conversation_id < 1
    ):
        return jsonify({"error": "Invalid conversation id."}), 400
    conversation = Conversation.query.filter_by(
        id=conversation_id, user_id=g.current_user.id
    ).first() if conversation_id is not None else None
    if conversation_id is not None and conversation is None:
        return jsonify({"error": "Conversation not found."}), 404
    if conversation is None:
        conversation = Conversation(title="New conversation", user_id=g.current_user.id)
        db.session.add(conversation)
        db.session.flush()

    if regenerate:
        history = Message.query.filter_by(conversation_id=conversation.id).order_by(
            Message.created_at, Message.id
        ).all()
        while history and history[-1].role == "assistant":
            db.session.delete(history.pop())
        if not history or history[-1].role != "user":
            db.session.rollback()
            return jsonify({"error": "There is no assistant response to regenerate."}), 409
    else:
        clean_text = message_text.strip()
        if not Message.query.filter_by(conversation_id=conversation.id).first():
            conversation.title = clean_text.replace("\n", " ")[:72]
            if len(clean_text) > 72:
                conversation.title += "…"
        db.session.add(Message(conversation_id=conversation.id, role="user", content=clean_text))

    conversation.updated_at = datetime.now(timezone.utc)
    db.session.flush()
    prior_messages = Message.query.filter_by(conversation_id=conversation.id).order_by(
        Message.created_at, Message.id
    ).all()
    # Keep the system prompt plus recent turns inside a practical context window.
    context = [{"role": item.role, "content": item.content} for item in prior_messages[-50:]]
    latest_user_text = next((item["content"] for item in reversed(context) if item["role"] == "user"), "")
    preference = g.current_user.language_preference
    turn_language = (
        explicit_language_target(latest_user_text)
        or (preference if preference in {"en", "ta"} else detect_language(latest_user_text))
    )
    if preference == "auto":
        # Old assistant turns in the other language can cause a small local
        # model to keep answering in that language after the student switches.
        context = [
            item for index, item in enumerate(context)
            if index == len(context) - 1 or detect_language(item["content"]) == turn_language
        ]
    else:
        context = [
            item for item in context
            if item["role"] != "assistant" or detect_language(item["content"]) == turn_language
        ]
    if context and context[-1]["role"] == "user":
        context[-1]["content"] = (
            f"[For this response, use {('Tamil (தமிழ்)' if turn_language == 'ta' else 'English')}. "
            "This instruction applies even if earlier messages used another language.]\n\n"
            + context[-1]["content"]
        )
    language_instruction = response_language_instruction(
        preference, latest_user_text
    )
    translate_tamil_input_to_english = turn_language == "en" and bool(TAMIL_RE.search(latest_user_text))
    ollama_messages = [
        {"role": "system", "content": f"{SYSTEM_PROMPT}\n\nResponse language preference: {language_instruction}"},
        *context,
    ]
    assistant = Message(
        conversation_id=conversation.id, role="assistant", content="", is_complete=False
    )
    db.session.add(assistant)
    db.session.commit()
    ids = {"conversation_id": conversation.id, "user_message_id": None if regenerate else prior_messages[-1].id,
           "assistant_message_id": assistant.id}
    app = current_app._get_current_object()
    model = app.config["OLLAMA_MODEL"]

    def generate_events():
        content = []
        complete = False
        yield _event("meta", {**ids, "model": model})
        with app.app_context():
            try:
                response_messages = ollama_messages
                if translate_tamil_input_to_english:
                    english_question = _ollama().chat([
                        {"role": "system", "content": "Translate the student's question into clear English only. Do not answer it. Preserve the meaning and academic terms."},
                        {"role": "user", "content": latest_user_text},
                    ], options={"temperature": 0})
                    response_messages = [dict(message) for message in ollama_messages]
                    response_messages[-1]["content"] = (
                        "Original student question (Tamil):\n" + latest_user_text +
                        "\n\nPossible English translation:\n" + english_question +
                        "\n\nAnswer the student's intended question in English. Treat the translation as a hint; "
                        "if it does not match the original meaning, state uncertainty instead of guessing."
                    )
                for fragment in _ollama().stream_chat(response_messages, options={"temperature": 0.2}):
                    content.append(fragment)
                    yield _event("token", {"content": fragment})
                stored_assistant = db.session.get(Message, ids["assistant_message_id"])
                if stored_assistant is not None:
                    stored_assistant.content = "".join(content)
                    stored_assistant.is_complete = True
                    conversation_row = db.session.get(Conversation, ids["conversation_id"])
                    conversation_row.updated_at = datetime.now(timezone.utc)
                    db.session.commit()
                    complete = True
                    yield _event("done", {"message": stored_assistant.to_dict()})
            except GeneratorExit:
                if complete:
                    pass
                elif content:
                    stored_assistant = db.session.get(Message, ids["assistant_message_id"])
                    if stored_assistant is not None:
                        stored_assistant.content = "".join(content)
                        stored_assistant.is_complete = False
                        db.session.commit()
                else:
                    db.session.query(Message).filter_by(id=ids["assistant_message_id"]).delete()
                    db.session.commit()
                raise
            except OllamaError as exc:
                db.session.query(Message).filter_by(id=ids["assistant_message_id"]).delete()
                db.session.commit()
                yield _event("error", {"message": str(exc)})
            except Exception:
                app.logger.exception("Unexpected error while streaming Ollama response")
                db.session.query(Message).filter_by(id=ids["assistant_message_id"]).delete()
                db.session.commit()
                yield _event("error", {"message": "The response was interrupted by an unexpected error."})
            finally:
                if not complete:
                    db.session.remove()

    return Response(
        stream_with_context(generate_events()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no"},
    )
