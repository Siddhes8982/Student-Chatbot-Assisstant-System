"""Student registration, login, profile, and dashboard pages."""

import re

from flask import Blueprint, flash, g, redirect, render_template, request, session, url_for
from sqlalchemy import func, or_
from sqlalchemy.exc import IntegrityError
from werkzeug.security import check_password_hash, generate_password_hash

from database import db
from models import Conversation, Message, User
from services.auth import login_required
from services.language import SUPPORTED_PREFERENCES

auth_bp = Blueprint("auth", __name__)

USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,30}$")
EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
MIN_PASSWORD_LENGTH = 10
MAX_PASSWORD_LENGTH = 128


def _validate_identity(username, email):
    if not USERNAME_RE.fullmatch(username):
        return "Username must be 3–30 characters using letters, numbers, dots, dashes, or underscores."
    if len(email) > 254 or not EMAIL_RE.fullmatch(email):
        return "Enter a valid email address."
    return None


def _validate_password(password):
    if len(password) < MIN_PASSWORD_LENGTH:
        return f"Use a password with at least {MIN_PASSWORD_LENGTH} characters."
    if len(password) > MAX_PASSWORD_LENGTH:
        return f"Passwords must be {MAX_PASSWORD_LENGTH} characters or fewer."
    return None


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if g.current_user is not None:
        return redirect(url_for("auth.dashboard"))
    if request.method == "GET":
        return render_template("auth/register.html")

    username = request.form.get("username", "").strip()
    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "")
    confirmation = request.form.get("confirm_password", "")
    error = _validate_identity(username, email) or _validate_password(password)
    if error:
        flash(error, "error")
        return render_template("auth/register.html", username=username, email=email), 400
    if password != confirmation:
        flash("Your passwords do not match.", "error")
        return render_template("auth/register.html", username=username, email=email), 400

    normalized_username = username.lower()
    existing = User.query.filter(or_(
        func.lower(User.username) == normalized_username,
        func.lower(User.email) == email,
    )).first()
    if existing:
        flash("That username or email is already registered. Try signing in instead.", "error")
        return render_template("auth/register.html", username=username, email=email), 409

    user = User(
        username=normalized_username,
        email=email,
        password_hash=generate_password_hash(password),
    )
    db.session.add(user)
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        flash("That username or email is already registered. Try signing in instead.", "error")
        return render_template("auth/register.html", username=username, email=email), 409

    session.clear()
    session["user_id"] = user.id
    session.permanent = True
    flash("Your StudyMate account is ready.", "success")
    return redirect(url_for("auth.dashboard"))


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if g.current_user is not None:
        return redirect(url_for("auth.dashboard"))
    if request.method == "GET":
        return render_template("auth/login.html")

    identifier = request.form.get("identifier", "").strip().lower()
    password = request.form.get("password", "")
    user = User.query.filter(or_(
        func.lower(User.username) == identifier,
        func.lower(User.email) == identifier,
    )).first() if identifier else None
    if user is None or not check_password_hash(user.password_hash, password):
        flash("We couldn’t sign you in with those details. Check them and try again.", "error")
        return render_template("auth/login.html", identifier=identifier), 401

    session.clear()
    session["user_id"] = user.id
    session.permanent = True
    flash(f"Welcome back, {user.username}.", "success")
    return redirect(url_for("auth.dashboard"))


@auth_bp.post("/logout")
@login_required
def logout():
    session.clear()
    flash("You’ve been signed out.", "success")
    return redirect(url_for("auth.login"))


@auth_bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    user = g.current_user
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        current_password = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        confirmation = request.form.get("confirm_password", "")
        language_preference = request.form.get("language_preference", user.language_preference)
        error = _validate_identity(username, email)
        if not error and language_preference not in SUPPORTED_PREFERENCES:
            error = "Choose automatic, English, or Tamil for your response language."
        if error:
            flash(error, "error")
        else:
            duplicate = User.query.filter(
                User.id != user.id,
                or_(func.lower(User.username) == username.lower(), func.lower(User.email) == email),
            ).first()
            if duplicate:
                error = "That username or email belongs to another account."
                flash(error, "error")
            elif new_password or confirmation:
                if not check_password_hash(user.password_hash, current_password):
                    error = "Enter your current password to change it."
                    flash(error, "error")
                elif (error := _validate_password(new_password)):
                    flash(error, "error")
                elif new_password != confirmation:
                    error = "Your new passwords do not match."
                    flash(error, "error")

        if not error:
            user.username = username.lower()
            user.email = email
            user.language_preference = language_preference
            if new_password:
                user.password_hash = generate_password_hash(new_password)
            try:
                db.session.commit()
                flash("Your profile has been updated.", "success")
                return redirect(url_for("auth.profile"))
            except IntegrityError:
                db.session.rollback()
                flash("That username or email is already in use.", "error")

    return render_template("auth/profile.html", user=user)


@auth_bp.get("/dashboard")
@login_required
def dashboard():
    user = g.current_user
    conversations = Conversation.query.filter_by(user_id=user.id).order_by(
        Conversation.updated_at.desc()
    ).limit(5).all()
    conversation_count = Conversation.query.filter_by(user_id=user.id).count()
    user_message_count = db.session.query(func.count(Message.id)).join(
        Conversation, Message.conversation_id == Conversation.id
    ).filter(Conversation.user_id == user.id, Message.role == "user").scalar()
    return render_template(
        "auth/dashboard.html",
        user=user,
        recent_conversations=conversations,
        conversation_count=conversation_count,
        question_count=user_message_count or 0,
    )
