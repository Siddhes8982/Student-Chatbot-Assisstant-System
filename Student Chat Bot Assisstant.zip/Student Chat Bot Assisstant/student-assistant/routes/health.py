"""Health and local Ollama readiness endpoint."""

from flask import Blueprint, current_app, jsonify

from services.ollama_service import OllamaError, OllamaService

health_bp = Blueprint("health", __name__)


@health_bp.get("/api/health")
def health():
    service = OllamaService(
        current_app.config["OLLAMA_BASE_URL"],
        current_app.config["OLLAMA_MODEL"],
        current_app.config["OLLAMA_TIMEOUT_SECONDS"],
    )
    try:
        ollama = service.status()
        ready = ollama["model_available"]
        return jsonify({"status": "ok" if ready else "degraded", "ollama": ollama}), (200 if ready else 503)
    except OllamaError as exc:
        return jsonify({
            "status": "degraded",
            "ollama": {
                "running": False,
                "model": current_app.config["OLLAMA_MODEL"],
                "model_available": False,
                "message": str(exc),
            },
        }), 503
