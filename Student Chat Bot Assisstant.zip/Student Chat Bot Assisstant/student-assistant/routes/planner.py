"""Private study planner pages, persistence APIs, and Ollama plan generation."""

import json
import re
from datetime import date, datetime, time, timedelta

from flask import Blueprint, current_app, g, jsonify, render_template, request
from sqlalchemy.exc import IntegrityError

from database import db
from models import StudyExam, StudySession, StudySubject, StudyTask
from services.auth import login_required
from services.ollama_service import OllamaError, OllamaService

planner_bp = Blueprint("planner", __name__)
DIFFICULTIES = {"easy", "medium", "hard"}
TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


class PlannerInputError(ValueError):
    pass


class PlannerNotFound(ValueError):
    pass


def _text(data, key, label, maximum, required=True):
    value = data.get(key, "")
    if not isinstance(value, str):
        raise PlannerInputError(f"{label} must be text.")
    value = value.strip()
    if required and not value:
        raise PlannerInputError(f"Enter a {label.lower()}.")
    if len(value) > maximum:
        raise PlannerInputError(f"{label} must be {maximum} characters or fewer.")
    return value


def _date(value, label, required=True):
    if value in (None, "") and not required:
        return None
    if not isinstance(value, str):
        raise PlannerInputError(f"{label} must be a date in YYYY-MM-DD format.")
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise PlannerInputError(f"{label} must be a date in YYYY-MM-DD format.") from exc


def _integer(data, key, label, minimum, maximum, default=None):
    value = data.get(key, default)
    if isinstance(value, bool):
        raise PlannerInputError(f"{label} must be between {minimum} and {maximum}.")
    try:
        value = int(value)
    except (TypeError, ValueError) as exc:
        raise PlannerInputError(f"{label} must be between {minimum} and {maximum}.") from exc
    if not minimum <= value <= maximum:
        raise PlannerInputError(f"{label} must be between {minimum} and {maximum}.")
    return value


def _subject(subject_id, optional=True):
    if subject_id in (None, "") and optional:
        return None
    try:
        subject_id = int(subject_id)
    except (TypeError, ValueError) as exc:
        raise PlannerInputError("Choose a valid subject.") from exc
    if subject_id < 1:
        raise PlannerInputError("Choose a valid subject.")
    item = StudySubject.query.filter_by(id=subject_id, user_id=g.current_user.id).first()
    if item is None:
        raise PlannerNotFound("Subject not found.")
    return item


def _handle_input_error(exc):
    if isinstance(exc, PlannerNotFound):
        return jsonify({"error": str(exc)}), 404
    return jsonify({"error": str(exc)}), 400


def _week_start(value):
    start = _date(value, "Week start") if value else date.today()
    return start - timedelta(days=start.weekday())


def _overview(week_start):
    user_id = g.current_user.id
    week_end = week_start + timedelta(days=6)
    subjects = StudySubject.query.filter_by(user_id=user_id).order_by(StudySubject.name).all()
    tasks = StudyTask.query.filter_by(user_id=user_id).all()
    pending = [item for item in tasks if not item.is_completed]
    completed = [item for item in tasks if item.is_completed]
    progress = round(len(completed) * 100 / len(tasks)) if tasks else 0
    exams = StudyExam.query.filter_by(user_id=user_id).filter(
        StudyExam.exam_date >= date.today()
    ).order_by(StudyExam.exam_date).limit(8).all()
    sessions = StudySession.query.filter_by(user_id=user_id).filter(
        StudySession.session_date >= week_start,
        StudySession.session_date <= week_end,
    ).order_by(StudySession.session_date, StudySession.start_time).all()
    pending.sort(key=lambda item: (item.due_date or date.max, item.created_at))
    completed.sort(key=lambda item: item.completed_at or item.created_at, reverse=True)
    return {
        "week_start": week_start.isoformat(),
        "week_end": week_end.isoformat(),
        "subjects": [item.to_dict() for item in subjects],
        "tasks": [item.to_dict() for item in pending[:100]],
        "completed_tasks": [item.to_dict() for item in completed[:100]],
        "exams": [item.to_dict() for item in exams],
        "sessions": [item.to_dict() for item in sessions],
        "stats": {
            "total_subjects": len(subjects),
            "total_tasks": len(tasks),
            "completed_tasks": len(completed),
            "pending_tasks": len(pending),
            "progress_percent": progress,
        },
    }


@planner_bp.get("/planner")
@login_required
def planner_page():
    return render_template("planner/index.html")


@planner_bp.get("/api/planner/overview")
@login_required
def overview():
    try:
        start = _week_start(request.args.get("week_start"))
    except PlannerInputError as exc:
        return _handle_input_error(exc)
    return jsonify(_overview(start))


@planner_bp.post("/api/planner/subjects")
@login_required
def create_subject():
    data = request.get_json(silent=True) or {}
    try:
        name = _text(data, "name", "Subject name", 80)
        difficulty = data.get("difficulty", "medium")
        if not isinstance(difficulty, str) or difficulty not in DIFFICULTIES:
            raise PlannerInputError("Choose easy, medium, or hard subject difficulty.")
        priority = _integer(data, "priority", "Priority", 1, 5, 3)
        if StudySubject.query.filter(
            StudySubject.user_id == g.current_user.id,
            db.func.lower(StudySubject.name) == name.lower(),
        ).first():
            return jsonify({"error": "You already have a subject with that name."}), 409
        subject = StudySubject(
            user_id=g.current_user.id, name=name, difficulty=difficulty, priority=priority
        )
        db.session.add(subject)
        db.session.commit()
        return jsonify({"subject": subject.to_dict()}), 201
    except PlannerInputError as exc:
        return _handle_input_error(exc)
    except IntegrityError:
        db.session.rollback()
        return jsonify({"error": "You already have a subject with that name."}), 409


@planner_bp.delete("/api/planner/subjects/<int:subject_id>")
@login_required
def delete_subject(subject_id):
    subject = StudySubject.query.filter_by(id=subject_id, user_id=g.current_user.id).first()
    if subject is None:
        return jsonify({"error": "Subject not found."}), 404
    StudyTask.query.filter_by(user_id=g.current_user.id, subject_id=subject.id).update(
        {"subject_id": None}, synchronize_session=False
    )
    StudyExam.query.filter_by(user_id=g.current_user.id, subject_id=subject.id).update(
        {"subject_id": None}, synchronize_session=False
    )
    StudySession.query.filter_by(user_id=g.current_user.id, subject_id=subject.id).update(
        {"subject_id": None}, synchronize_session=False
    )
    db.session.delete(subject)
    db.session.commit()
    return jsonify({"deleted": True})


@planner_bp.post("/api/planner/tasks")
@login_required
def create_task():
    data = request.get_json(silent=True) or {}
    try:
        title = _text(data, "title", "Task title", 160)
        description = _text(data, "description", "Description", 1200, required=False)
        subject = _subject(data.get("subject_id"))
        due_date = _date(data.get("due_date"), "Deadline", required=False)
        minutes = _integer(data, "estimated_minutes", "Estimated minutes", 10, 480, 60)
        task = StudyTask(
            user_id=g.current_user.id,
            subject_id=subject.id if subject else None,
            title=title,
            description=description,
            due_date=due_date,
            estimated_minutes=minutes,
        )
        db.session.add(task)
        db.session.commit()
        return jsonify({"task": task.to_dict()}), 201
    except (PlannerInputError, PlannerNotFound) as exc:
        return _handle_input_error(exc)


@planner_bp.patch("/api/planner/tasks/<int:task_id>")
@login_required
def update_task(task_id):
    task = StudyTask.query.filter_by(id=task_id, user_id=g.current_user.id).first()
    if task is None:
        return jsonify({"error": "Task not found."}), 404
    data = request.get_json(silent=True) or {}
    try:
        if "is_completed" in data:
            if not isinstance(data["is_completed"], bool):
                raise PlannerInputError("Task completion must be true or false.")
            task.is_completed = data["is_completed"]
            task.completed_at = datetime.utcnow() if task.is_completed else None
        if "title" in data:
            task.title = _text(data, "title", "Task title", 160)
        if "description" in data:
            task.description = _text(data, "description", "Description", 1200, required=False)
        if "due_date" in data:
            task.due_date = _date(data["due_date"], "Deadline", required=False)
        if "estimated_minutes" in data:
            task.estimated_minutes = _integer(data, "estimated_minutes", "Estimated minutes", 10, 480)
        if "subject_id" in data:
            subject = _subject(data["subject_id"])
            task.subject_id = subject.id if subject else None
        db.session.commit()
        return jsonify({"task": task.to_dict()})
    except (PlannerInputError, PlannerNotFound) as exc:
        db.session.rollback()
        return _handle_input_error(exc)


@planner_bp.delete("/api/planner/tasks/<int:task_id>")
@login_required
def delete_task(task_id):
    task = StudyTask.query.filter_by(id=task_id, user_id=g.current_user.id).first()
    if task is None:
        return jsonify({"error": "Task not found."}), 404
    StudySession.query.filter_by(user_id=g.current_user.id, task_id=task.id).update(
        {"task_id": None}, synchronize_session=False
    )
    db.session.delete(task)
    db.session.commit()
    return jsonify({"deleted": True})


@planner_bp.post("/api/planner/exams")
@login_required
def create_exam():
    data = request.get_json(silent=True) or {}
    try:
        title = _text(data, "title", "Exam name", 120)
        subject = _subject(data.get("subject_id"), optional=False)
        exam_date = _date(data.get("exam_date"), "Exam date")
        exam = StudyExam(
            user_id=g.current_user.id, subject_id=subject.id, title=title, exam_date=exam_date
        )
        db.session.add(exam)
        db.session.commit()
        return jsonify({"exam": exam.to_dict()}), 201
    except (PlannerInputError, PlannerNotFound) as exc:
        return _handle_input_error(exc)


@planner_bp.delete("/api/planner/exams/<int:exam_id>")
@login_required
def delete_exam(exam_id):
    exam = StudyExam.query.filter_by(id=exam_id, user_id=g.current_user.id).first()
    if exam is None:
        return jsonify({"error": "Exam not found."}), 404
    db.session.delete(exam)
    db.session.commit()
    return jsonify({"deleted": True})


@planner_bp.post("/api/planner/sessions")
@login_required
def create_session():
    data = request.get_json(silent=True) or {}
    try:
        title = _text(data, "title", "Study session title", 160)
        session_date = _date(data.get("date"), "Study date")
        start_time = data.get("start_time", "09:00")
        if not isinstance(start_time, str) or not TIME_RE.fullmatch(start_time):
            raise PlannerInputError("Start time must use 24-hour HH:MM format.")
        duration = _integer(data, "duration_minutes", "Duration", 15, 360, 60)
        subject = _subject(data.get("subject_id"))
        task_id = data.get("task_id")
        task = None
        if task_id not in (None, ""):
            try:
                task_id = int(task_id)
            except (TypeError, ValueError) as exc:
                raise PlannerInputError("Choose a valid task.") from exc
            task = StudyTask.query.filter_by(id=task_id, user_id=g.current_user.id).first()
            if task is None:
                raise PlannerNotFound("Task not found.")
            if subject and task.subject_id and subject.id != task.subject_id:
                raise PlannerInputError("The selected task belongs to a different subject.")
            if subject is None and task.subject_id:
                subject = StudySubject.query.filter_by(id=task.subject_id, user_id=g.current_user.id).first()
        item = StudySession(
            user_id=g.current_user.id,
            subject_id=subject.id if subject else None,
            task_id=task.id if task else None,
            title=title,
            session_date=session_date,
            start_time=start_time,
            duration_minutes=duration,
            source="manual",
        )
        db.session.add(item)
        db.session.commit()
        return jsonify({"session": item.to_dict()}), 201
    except (PlannerInputError, PlannerNotFound) as exc:
        return _handle_input_error(exc)


@planner_bp.patch("/api/planner/sessions/<int:session_id>")
@login_required
def update_session(session_id):
    item = StudySession.query.filter_by(id=session_id, user_id=g.current_user.id).first()
    if item is None:
        return jsonify({"error": "Study session not found."}), 404
    data = request.get_json(silent=True) or {}
    if not isinstance(data.get("is_completed"), bool):
        return jsonify({"error": "Session completion must be true or false."}), 400
    item.is_completed = data["is_completed"]
    db.session.commit()
    return jsonify({"session": item.to_dict()})


@planner_bp.delete("/api/planner/sessions/<int:session_id>")
@login_required
def delete_session(session_id):
    item = StudySession.query.filter_by(id=session_id, user_id=g.current_user.id).first()
    if item is None:
        return jsonify({"error": "Study session not found."}), 404
    db.session.delete(item)
    db.session.commit()
    return jsonify({"deleted": True})


def _plan_schema(subject_names):
    return {
        "type": "object",
        "properties": {
            "sessions": {
                "type": "array",
                "minItems": 7,
                "maxItems": 7,
                "items": {
                    "type": "object",
                    "properties": {
                        "date": {"type": "string", "pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}$"},
                        "start_time": {"type": "string", "pattern": "^([01][0-9]|2[0-3]):[0-5][0-9]$"},
                        "duration_minutes": {"type": "integer", "minimum": 25, "maximum": 180},
                        "subject": {"type": "string", "enum": subject_names},
                        "title": {"type": "string"},
                    },
                    "required": ["date", "start_time", "duration_minutes", "subject", "title"],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["sessions"],
        "additionalProperties": False,
    }


@planner_bp.post("/api/planner/ai-plan")
@login_required
def generate_weekly_plan():
    data = request.get_json(silent=True) or {}
    raw_hours = data.get("hours_per_day", 3)
    if isinstance(raw_hours, bool):
        return jsonify({"error": "Available hours must be between 0.5 and 12 per day."}), 400
    try:
        hours = float(raw_hours)
    except (TypeError, ValueError):
        return jsonify({"error": "Available hours must be between 0.5 and 12 per day."}), 400
    if not 0.5 <= hours <= 12:
        return jsonify({"error": "Available hours must be between 0.5 and 12 per day."}), 400
    try:
        week_start = _week_start(data.get("week_start"))
    except PlannerInputError as exc:
        return _handle_input_error(exc)

    subjects = StudySubject.query.filter_by(user_id=g.current_user.id).order_by(
        StudySubject.priority.desc(), StudySubject.name
    ).all()
    if not subjects:
        return jsonify({"error": "Add at least one subject before generating a study plan."}), 400
    week_end = week_start + timedelta(days=6)
    exams = StudyExam.query.filter_by(user_id=g.current_user.id).filter(
        StudyExam.exam_date >= week_start - timedelta(days=1),
        StudyExam.exam_date <= week_start + timedelta(days=90),
    ).order_by(StudyExam.exam_date).all()
    tasks = StudyTask.query.filter_by(user_id=g.current_user.id, is_completed=False).order_by(
        StudyTask.due_date
    ).limit(24).all()
    subject_context = [
        {"subject": item.name, "difficulty": item.difficulty, "priority": item.priority}
        for item in subjects
    ]
    exam_context = [
        {"subject": item.subject.name if item.subject else "General", "title": item.title,
         "date": item.exam_date.isoformat()}
        for item in exams
    ]
    task_context = [
        {"title": item.title, "subject": item.subject.name if item.subject else "General",
         "deadline": item.due_date.isoformat() if item.due_date else None,
         "minutes": item.estimated_minutes}
        for item in tasks
    ]
    prompt = f"""Create a personalized, realistic weekly study schedule using the student's actual data.
Week begins on Monday {week_start.isoformat()} and ends Sunday {week_end.isoformat()}.
Available study time: no more than {hours:g} hours per day.
Student subjects (difficulty and priority 1–5): {json.dumps(subject_context, ensure_ascii=False)}
Upcoming examination dates: {json.dumps(exam_context, ensure_ascii=False)}
Pending tasks and deadlines: {json.dumps(task_context, ensure_ascii=False)}

Return exactly seven sessions: one session on each date from Monday through Sunday, with no second session on any date. For every date, use exactly the YYYY-MM-DD string format (for example, 2026-11-09), with no weekday or time suffix. For start_time use exactly 24-hour HH:MM. Distribute subjects across the week, giving more days to harder and higher-priority subjects and subjects with nearer exams. Include pending task work before its deadline where useful. Each session must fit within the daily available study hours. Use study blocks of 25 to 180 minutes. Only use the exact subject names provided. Titles should be concrete study activities, not generic placeholders. Output only the requested JSON structure."""

    schema = _plan_schema([item.name for item in subjects])
    try:
        raw = OllamaService(
            current_app.config["OLLAMA_BASE_URL"],
            current_app.config["OLLAMA_MODEL"],
            current_app.config["OLLAMA_TIMEOUT_SECONDS"],
        ).chat([
            {"role": "system", "content": "You are StudyMate AI, a careful study-planning tutor. Personalize schedules to the student data. Never invent subjects or exams. Return only valid structured output."},
            {"role": "user", "content": prompt},
        ], response_format=schema)
        result = json.loads(raw)
        raw_sessions = result.get("sessions") if isinstance(result, dict) else None
        if not isinstance(raw_sessions, list) or len(raw_sessions) < 7:
            raise OllamaError("The planner could not create a complete seven-day schedule. Please try again.")
        subject_lookup = {item.name.casefold(): item for item in subjects}
        prepared = []
        per_day_minutes = {}
        intervals = {}
        date_set = {week_start + timedelta(days=index) for index in range(7)}
        for item in raw_sessions:
            if not isinstance(item, dict):
                continue
            try:
                session_date = date.fromisoformat(item.get("date", ""))
            except (TypeError, ValueError):
                raise OllamaError("The planner returned an invalid date. Please generate the plan again.")
            start_time = item.get("start_time", "")
            duration = item.get("duration_minutes")
            name = item.get("subject", "")
            title = item.get("title", "")
            if session_date not in date_set or not isinstance(start_time, str) or not TIME_RE.fullmatch(start_time):
                raise OllamaError("The planner returned a session outside the selected week or an invalid time.")
            if isinstance(duration, bool) or not isinstance(duration, int) or not 25 <= duration <= 180:
                raise OllamaError("The planner returned an invalid study-session length.")
            subject = subject_lookup.get(name.casefold()) if isinstance(name, str) else None
            if subject is None or not isinstance(title, str) or not title.strip():
                raise OllamaError("The planner returned a session without a valid subject or activity.")
            start = datetime.combine(session_date, time.fromisoformat(start_time))
            end = start + timedelta(minutes=duration)
            day_intervals = intervals.setdefault(session_date, [])
            if any(start < other_end and end > other_start for other_start, other_end in day_intervals):
                raise OllamaError("The generated plan contains overlapping study sessions. Please try again.")
            day_intervals.append((start, end))
            per_day_minutes[session_date] = per_day_minutes.get(session_date, 0) + duration
            prepared.append((subject, session_date, start_time, duration, title.strip()))
        if set(per_day_minutes) != date_set:
            raise OllamaError("The planner did not include every day in the week. Please try again.")
        if any(minutes > hours * 60 for minutes in per_day_minutes.values()):
            raise OllamaError("The generated plan exceeds your daily available hours. Please try again.")

        # Regenerating replaces this student's AI-generated sessions for the
        # selected week while preserving manually-created calendar entries.
        StudySession.query.filter(
            StudySession.user_id == g.current_user.id,
            StudySession.source == "ai",
            StudySession.session_date >= week_start,
            StudySession.session_date <= week_end,
        ).delete(synchronize_session=False)
        saved = [StudySession(
            user_id=g.current_user.id,
            subject_id=subject.id,
            title=title,
            session_date=session_date,
            start_time=start_time,
            duration_minutes=duration,
            source="ai",
        ) for subject, session_date, start_time, duration, title in prepared]
        db.session.add_all(saved)
        db.session.commit()
        return jsonify({
            "week_start": week_start.isoformat(),
            "sessions": [item.to_dict() for item in saved],
            "message": f"Your personalized plan is saved for {len(saved)} study sessions this week.",
        })
    except (OllamaError, json.JSONDecodeError) as exc:
        db.session.rollback()
        message = str(exc) if isinstance(exc, OllamaError) else "The planner returned invalid structured data. Please try again."
        return jsonify({"error": message}), 503
