"""Authentication helpers shared by page and API routes."""

from functools import wraps

from flask import g, jsonify, redirect, request, url_for


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.get("current_user") is not None:
            return view(*args, **kwargs)
        if request.path.startswith("/api/"):
            return jsonify({"error": "Sign in to continue."}), 401
        return redirect(url_for("auth.login"))

    return wrapped
