"""Local PDF extraction, embedding, FAISS storage, and private retrieval."""

import os
import re
import shutil
import threading
import uuid
from pathlib import Path

import numpy as np
from flask import current_app
from werkzeug.utils import secure_filename

from database import db
from models import RagChunk, RagDocument


class RagError(RuntimeError):
    """Friendly local document-processing or retrieval failure."""


_model = None
_model_key = None
_model_lock = threading.Lock()


def _dependencies():
    try:
        import pymupdf
        import faiss
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise RagError("PDF study dependencies are missing. Install the packages in requirements.txt and restart StudyMate.") from exc
    return pymupdf, faiss, SentenceTransformer


def _embedding_model():
    global _model, _model_key
    _, _, SentenceTransformer = _dependencies()
    name = current_app.config["RAG_EMBEDDING_MODEL"]
    with _model_lock:
        if _model is None or _model_key != name:
            try:
                try:
                    # Cached weights load without any network access after the
                    # initial model setup. Fall back to fetching weights only
                    # when the model has not been cached on this machine yet.
                    _model = SentenceTransformer(name, device="cpu", local_files_only=True)
                except Exception:
                    _model = SentenceTransformer(name, device="cpu", local_files_only=False)
                _model_key = name
            except Exception as exc:
                raise RagError(
                    f"Could not load the local embedding model '{name}'. Ensure its model files are available, then retry."
                ) from exc
    return _model


def _user_dir(user_id):
    root = Path(current_app.config["RAG_STORAGE_DIR"]).resolve()
    target = (root / str(user_id)).resolve()
    if root not in target.parents:
        raise RagError("The private document storage path is invalid.")
    target.mkdir(parents=True, exist_ok=True)
    return target


def _document_dir(document):
    root = _user_dir(document.user_id)
    target = (root / document.storage_key).resolve()
    if root not in target.parents:
        raise RagError("The document storage path is invalid.")
    target.mkdir(parents=True, exist_ok=True)
    return target


def _clean_page(text):
    text = text.replace("\u00ad", "")
    text = re.sub(r"(?<=\w)-\s*\n\s*(?=\w)", "", text)
    text = re.sub(r"[\t\r\f\v]+", " ", text)
    text = re.sub(r" *\n+ *", "\n", text)
    text = re.sub(r" {2,}", " ", text)
    return text.strip()


def _chunk_pages(pages, size, overlap):
    chunks = []
    stride = max(1, size - overlap)
    for page_number, page_text in pages:
        text = _clean_page(page_text)
        if not text:
            continue
        start = 0
        while start < len(text):
            end = min(len(text), start + size)
            if end < len(text):
                boundary = max(text.rfind("\n", start, end), text.rfind(". ", start, end), text.rfind(" ", start, end))
                if boundary > start + size // 2:
                    end = boundary + (1 if text[boundary:boundary + 1] == "\n" else 0)
            content = text[start:end].strip()
            if len(content) >= 30:
                chunks.append((page_number, content))
            if end >= len(text):
                break
            start = max(start + 1, end - overlap)
    return chunks


def process_pdf(document, pdf_bytes):
    pymupdf, faiss, _ = _dependencies()
    directory = _document_dir(document)
    try:
        pdf = pymupdf.open(stream=pdf_bytes, filetype="pdf")
        if pdf.is_encrypted:
            raise RagError("This PDF is password-protected. Upload an unlocked copy.")
        pages = [(index + 1, page.get_text("text")) for index, page in enumerate(pdf)]
        pdf.close()
    except RagError:
        raise
    except Exception as exc:
        raise RagError("This file could not be read as a PDF. Try exporting or saving it again.") from exc
    chunks = _chunk_pages(pages, current_app.config["RAG_CHUNK_SIZE"], current_app.config["RAG_CHUNK_OVERLAP"])
    if not chunks:
        raise RagError("No selectable text was found in this PDF. Scanned PDFs need OCR before upload.")
    try:
        vectors = _embedding_model().encode(
            [content for _, content in chunks],
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        vectors = np.asarray(vectors, dtype=np.float32)
        index = faiss.IndexFlatIP(vectors.shape[1])
        index.add(vectors)
        source_path = directory / "document.pdf"
        source_path.write_bytes(pdf_bytes)
        index_path = directory / "vectors.faiss"
        temp_index = directory / "vectors.tmp.faiss"
        faiss.write_index(index, str(temp_index))
        os.replace(temp_index, index_path)
        for chunk_index, ((page_number, content), vector) in enumerate(zip(chunks, vectors)):
            db.session.add(RagChunk(
                user_id=document.user_id,
                document_id=document.id,
                chunk_index=chunk_index,
                page_number=page_number,
                content=content,
                embedding=vector.tobytes(),
            ))
        document.chunk_count = len(chunks)
        document.status = "ready"
        document.error_message = None
        db.session.commit()
    except RagError:
        raise
    except Exception as exc:
        db.session.rollback()
        raise RagError("The local embedding index could not be created. Please retry this PDF.") from exc


def delete_document_files(document):
    directory = _document_dir(document)
    if directory.exists():
        shutil.rmtree(directory)


def retrieve(user_id, question, top_k):
    _, faiss, _ = _dependencies()
    model = _embedding_model()
    query = np.asarray(model.encode([question], convert_to_numpy=True, normalize_embeddings=True), dtype=np.float32)
    documents = RagDocument.query.filter_by(user_id=user_id, status="ready").order_by(RagDocument.created_at.desc()).all()
    candidates = []
    # Load all of this student's chunks in one query instead of issuing one
    # query per document in the student's library.
    chunks_by_document = {}
    document_ids = [document.id for document in documents]
    if document_ids:
        all_chunks = RagChunk.query.filter(
            RagChunk.user_id == user_id,
            RagChunk.document_id.in_(document_ids),
        ).order_by(RagChunk.document_id, RagChunk.chunk_index).all()
        for chunk in all_chunks:
            chunks_by_document.setdefault(chunk.document_id, []).append(chunk)
    for document in documents:
        index_path = _document_dir(document) / "vectors.faiss"
        if not index_path.is_file():
            continue
        try:
            index = faiss.read_index(str(index_path))
            scores, positions = index.search(query, min(top_k, index.ntotal))
        except Exception:
            continue
        chunks = chunks_by_document.get(document.id, [])
        for score, position in zip(scores[0], positions[0]):
            if position < 0 or position >= len(chunks):
                continue
            chunk = chunks[int(position)]
            candidates.append({
                "score": float(score), "document_id": document.id, "filename": document.filename,
                "page": chunk.page_number, "content": chunk.content,
            })
    candidates.sort(key=lambda item: item["score"], reverse=True)
    # Avoid distracting the answer model with merely adjacent but unrelated
    # pages (for example, photosynthesis text matching a biology query about
    # mitochondria only because both mention ATP).
    if candidates:
        relevance_floor = max(0.0, candidates[0]["score"] - 0.20)
        candidates = [item for item in candidates if item["score"] >= relevance_floor]
    unique = []
    seen = set()
    for item in candidates:
        key = (item["filename"], item["page"], item["content"])
        if key not in seen:
            seen.add(key)
            unique.append(item)
        if len(unique) >= top_k:
            break
    return unique


def add_document(user_id, filename, pdf_bytes):
    clean_name = secure_filename(filename or "")
    if not clean_name or not clean_name.lower().endswith(".pdf"):
        raise RagError("Choose a PDF file to upload.")
    key = uuid.uuid4().hex
    document = RagDocument(
        user_id=user_id, filename=clean_name[:255], storage_key=key, status="processing"
    )
    db.session.add(document)
    db.session.commit()
    try:
        process_pdf(document, pdf_bytes)
    except RagError as exc:
        db.session.rollback()
        document = RagDocument.query.filter_by(id=document.id, user_id=user_id).first()
        if document:
            document.status = "failed"
            document.error_message = str(exc)[:500]
            db.session.commit()
        try:
            delete_document_files(document) if document else None
        except OSError:
            pass
        raise
    return document


def private_storage_path(document):
    return _document_dir(document)
