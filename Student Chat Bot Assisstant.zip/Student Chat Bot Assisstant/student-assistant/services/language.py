"""Shared language preferences and response instructions for local AI features."""

import re


SUPPORTED_PREFERENCES = {"auto", "en", "ta"}
TAMIL_RE = re.compile(r"[\u0B80-\u0BFF]")
ENGLISH_TARGET_RE = re.compile(
    r"\b(?:in|into)\s+English\b|English[- ](?:la|le|please)\b|English[- ][\u0B80-\u0BFF]+|"
    r"\u0b86\u0b99\u0bcd\u0b95\u0bbf\u0bb2\u0ba4\u0bcd\u0ba4\u0bbf\u0bb2\u0bcd|"
    r"\u0b86\u0b99\u0bcd\u0b95\u0bbf\u0bb2\u0bae\u0bbe\u0b95|\u0b86\u0b99\u0bcd\u0b95\u0bbf\u0bb2\u0bae\u0bcd",
    re.IGNORECASE,
)
TAMIL_TARGET_RE = re.compile(
    r"\b(?:in|into)\s+Tamil\b|Tamil[- ](?:la|le|please)\b|Tamil[- ][\u0B80-\u0BFF]+|"
    r"\u0ba4\u0bae\u0bbf\u0bb4\u0bbf\u0bb2\u0bcd|\u0ba4\u0bae\u0bbf\u0bb4\u0bbe\u0b95",
    re.IGNORECASE,
)


def explicit_language_target(text=""):
    if ENGLISH_TARGET_RE.search(text or ""):
        return "en"
    if TAMIL_TARGET_RE.search(text or ""):
        return "ta"
    return None


def detect_language(text=""):
    text = text or ""
    target = explicit_language_target(text)
    if target:
        return target
    tamil_letters = len(TAMIL_RE.findall(text))
    latin_letters = len(re.findall(r"[A-Za-z]", text))
    return "ta" if tamil_letters and tamil_letters >= latin_letters * 0.7 else "en"


def response_language_instruction(preference="auto", latest_text=""):
    if preference == "ta":
        return (
            "Respond in accurate, natural Tamil (தமிழ்), using correct Tamil spelling and standard academic vocabulary. "
            "If a technical Tamil term is uncertain, keep the English term and explain it in Tamil; do not invent "
            "a Tamil translation. Keep technical terms in English in parentheses when useful. If the student explicitly requests an English translation or answer, follow "
            "that request; for translation tasks, provide the requested source and target languages."
        )
    if preference == "en":
        return (
            "Respond in clear English. If the student explicitly requests a Tamil translation or answer, "
            "follow that request; for translation tasks, provide the requested source and target languages."
        )
    detected = detect_language(latest_text)
    language_name = "Tamil (தமிழ்)" if detected == "ta" else "English"
    return (
        f"The latest student message is in {language_name}. Respond in {language_name}; do not continue "
        "in a previous turn's language. Support both English and Tamil (தமிழ்). If the student explicitly "
        "asks for a translation or explanation in another language, follow that requested target language "
        "and make the source and target clear."
    )


def output_language_instruction(mode="auto", *, bilingual_notes=False, sample_text=""):
    if mode == "bilingual" and bilingual_notes:
        return (
            "Write every note section bilingually: provide the English version first, followed by an "
            "accurate, natural Tamil (தமிழ்) version. Keep formulas, code, and standard technical terms clear."
        )
    return response_language_instruction(mode, sample_text)


def missing_answer_message(preference="auto", user_text=""):
    language = explicit_language_target(user_text) or preference
    if language == "auto":
        language = detect_language(user_text)
    if language == "ta":
        return "பதிவேற்றிய ஆவணங்களில் இதற்கான பதிலை நான் கண்டுபிடிக்க முடியவில்லை."
    if language == "bilingual":
        return (
            "I couldn't find the answer in the uploaded documents.\n\n"
            "பதிவேற்றிய ஆவணங்களில் இதற்கான பதிலை நான் கண்டுபிடிக்க முடியவில்லை."
        )
    return "I couldn't find the answer in the uploaded documents."
