"""HTTP client for the local Ollama API."""

import json

import requests


class OllamaError(RuntimeError):
    """A friendly, actionable Ollama availability or API error."""


class OllamaService:
    def __init__(self, base_url, model="llama3.2", timeout=120):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout

    def _get(self, path):
        try:
            response = requests.get(f"{self.base_url}{path}", timeout=(3.05, min(self.timeout, 10)))
            response.raise_for_status()
            return response.json()
        except requests.ConnectionError as exc:
            raise OllamaError(
                "Ollama is offline or unreachable. Start Ollama, then try again."
            ) from exc
        except requests.Timeout as exc:
            raise OllamaError("Ollama did not respond in time. Please try again.") from exc
        except (requests.RequestException, ValueError) as exc:
            raise OllamaError("Ollama returned an unexpected response. Please try again.") from exc

    def status(self):
        """Return connectivity and configured-model availability."""
        data = self._get("/api/tags")
        installed = [item.get("name", "") for item in data.get("models", [])]
        available = any(
            name == self.model or name.split(":", 1)[0] == self.model.split(":", 1)[0]
            for name in installed
        )
        return {
            "running": True,
            "model": self.model,
            "model_available": available,
            "message": None if available else (
                f"Model '{self.model}' is not installed. Run 'ollama pull {self.model}'."
            ),
        }

    def chat(self, messages, response_format=None, options=None):
        """Return a complete local /api/chat response for non-streaming tools."""
        response = None
        try:
            payload = {"model": self.model, "messages": messages, "stream": False}
            if response_format is not None:
                payload["format"] = response_format
            if options is not None:
                payload["options"] = options
            response = requests.post(
                f"{self.base_url}/api/chat",
                json=payload,
                timeout=(3.05, self.timeout),
            )
            response.raise_for_status()
            result = response.json()
            content = result.get("message", {}).get("content")
            if not isinstance(content, str) or not content.strip():
                raise OllamaError("Ollama returned an empty response. Please try again.")
            return content
        except requests.ConnectionError as exc:
            raise OllamaError(
                "Ollama is offline or unreachable. Start Ollama, then try again."
            ) from exc
        except requests.Timeout as exc:
            raise OllamaError("Ollama took too long to respond. Please try again.") from exc
        except requests.HTTPError as exc:
            body = ""
            if exc.response is not None:
                try:
                    body = exc.response.json().get("error", "")
                except ValueError:
                    body = exc.response.text
            if "not found" in body.lower() and "model" in body.lower():
                raise OllamaError(
                    f"Model '{self.model}' is not installed. Run 'ollama pull {self.model}'."
                ) from exc
            raise OllamaError("Ollama could not complete this request. Please try again.") from exc
        except (requests.RequestException, ValueError) as exc:
            raise OllamaError("Ollama returned an unexpected response. Please try again.") from exc
        finally:
            if response is not None:
                response.close()

    def stream_chat(self, messages, options=None):
        """Yield assistant text fragments from Ollama's streaming /api/chat API."""
        response = None
        finished = False
        try:
            payload = {"model": self.model, "messages": messages, "stream": True}
            if options is not None:
                payload["options"] = options
            response = requests.post(
                f"{self.base_url}/api/chat",
                json=payload,
                stream=True,
                timeout=(3.05, self.timeout),
            )
            response.raise_for_status()
            response.encoding = "utf-8"
            for line in response.iter_lines(decode_unicode=True):
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except (TypeError, json.JSONDecodeError) as exc:
                    raise OllamaError("Ollama sent an unreadable streaming response.") from exc
                if payload.get("error"):
                    message = payload["error"]
                    if "not found" in message.lower() and "model" in message.lower():
                        raise OllamaError(
                            f"Model '{self.model}' is not installed. Run 'ollama pull {self.model}'."
                        )
                    raise OllamaError("Ollama could not complete this response. Please try again.")
                text = payload.get("message", {}).get("content", "")
                if text:
                    yield text
                if payload.get("done") is True:
                    finished = True
                    break
            if not finished:
                raise OllamaError("Ollama ended the stream before finishing its response. Please try again.")
        except requests.ConnectionError as exc:
            raise OllamaError(
                "Ollama is offline or unreachable. Start Ollama, then try again."
            ) from exc
        except requests.Timeout as exc:
            raise OllamaError("Ollama took too long to respond. Please try again.") from exc
        except requests.HTTPError as exc:
            body = ""
            if exc.response is not None:
                try:
                    body = exc.response.json().get("error", "")
                except ValueError:
                    body = exc.response.text
            if "not found" in body.lower() and "model" in body.lower():
                raise OllamaError(
                    f"Model '{self.model}' is not installed. Run 'ollama pull {self.model}'."
                ) from exc
            raise OllamaError("Ollama could not complete this response. Please try again.") from exc
        except requests.RequestException as exc:
            raise OllamaError("The Ollama connection was interrupted. Please try again.") from exc
        finally:
            if response is not None:
                response.close()
