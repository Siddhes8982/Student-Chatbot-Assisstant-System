"""Persistent chat conversation and message models."""

from datetime import datetime, timezone

from database import db
from sqlalchemy import UniqueConstraint


def utcnow():
    return datetime.now(timezone.utc)


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(30), nullable=False, unique=True, index=True)
    email = db.Column(db.String(254), nullable=False, unique=True, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    language_preference = db.Column(db.String(12), nullable=False, default="auto")
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    conversations = db.relationship(
        "Conversation", back_populates="user", cascade="all, delete-orphan"
    )
    study_subjects = db.relationship("StudySubject", back_populates="user", cascade="all, delete-orphan")
    study_tasks = db.relationship("StudyTask", back_populates="user", cascade="all, delete-orphan")
    exams = db.relationship("StudyExam", back_populates="user", cascade="all, delete-orphan")
    study_sessions = db.relationship("StudySession", back_populates="user", cascade="all, delete-orphan")
    rag_documents = db.relationship("RagDocument", cascade="all, delete-orphan")


class StudySubject(db.Model):
    __tablename__ = "study_subjects"
    __table_args__ = (UniqueConstraint("user_id", "name", name="uq_study_subject_user_name"),)

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    name = db.Column(db.String(80), nullable=False)
    difficulty = db.Column(db.String(12), nullable=False, default="medium")
    priority = db.Column(db.Integer, nullable=False, default=3)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    user = db.relationship("User", back_populates="study_subjects")
    tasks = db.relationship("StudyTask", back_populates="subject")
    exams = db.relationship("StudyExam", back_populates="subject")
    sessions = db.relationship("StudySession", back_populates="subject")

    def to_dict(self):
        return {"id": self.id, "name": self.name, "difficulty": self.difficulty, "priority": self.priority}


class StudyTask(db.Model):
    __tablename__ = "study_tasks"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    subject_id = db.Column(db.Integer, db.ForeignKey("study_subjects.id", ondelete="SET NULL"), nullable=True, index=True)
    title = db.Column(db.String(160), nullable=False)
    description = db.Column(db.String(1200), nullable=False, default="")
    due_date = db.Column(db.Date, nullable=True, index=True)
    estimated_minutes = db.Column(db.Integer, nullable=False, default=60)
    is_completed = db.Column(db.Boolean, nullable=False, default=False, index=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    completed_at = db.Column(db.DateTime(timezone=True), nullable=True)
    user = db.relationship("User", back_populates="study_tasks")
    subject = db.relationship("StudySubject", back_populates="tasks")
    sessions = db.relationship("StudySession", back_populates="task")

    def to_dict(self):
        return {
            "id": self.id, "subject_id": self.subject_id,
            "subject": self.subject.name if self.subject else None,
            "title": self.title, "description": self.description,
            "due_date": self.due_date.isoformat() if self.due_date else None,
            "estimated_minutes": self.estimated_minutes,
            "is_completed": self.is_completed,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


class StudyExam(db.Model):
    __tablename__ = "study_exams"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    subject_id = db.Column(db.Integer, db.ForeignKey("study_subjects.id", ondelete="SET NULL"), nullable=True, index=True)
    title = db.Column(db.String(120), nullable=False)
    exam_date = db.Column(db.Date, nullable=False, index=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    user = db.relationship("User", back_populates="exams")
    subject = db.relationship("StudySubject", back_populates="exams")

    def to_dict(self):
        return {
            "id": self.id, "subject_id": self.subject_id,
            "subject": self.subject.name if self.subject else None,
            "title": self.title, "exam_date": self.exam_date.isoformat(),
        }


class StudySession(db.Model):
    __tablename__ = "study_sessions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    subject_id = db.Column(db.Integer, db.ForeignKey("study_subjects.id", ondelete="SET NULL"), nullable=True, index=True)
    task_id = db.Column(db.Integer, db.ForeignKey("study_tasks.id", ondelete="SET NULL"), nullable=True, index=True)
    title = db.Column(db.String(160), nullable=False)
    session_date = db.Column(db.Date, nullable=False, index=True)
    start_time = db.Column(db.String(5), nullable=False)
    duration_minutes = db.Column(db.Integer, nullable=False)
    source = db.Column(db.String(12), nullable=False, default="manual")
    is_completed = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    user = db.relationship("User", back_populates="study_sessions")
    subject = db.relationship("StudySubject", back_populates="sessions")
    task = db.relationship("StudyTask", back_populates="sessions")

    def to_dict(self):
        return {
            "id": self.id, "subject_id": self.subject_id,
            "subject": self.subject.name if self.subject else None,
            "task_id": self.task_id, "title": self.title,
            "date": self.session_date.isoformat(), "start_time": self.start_time,
            "duration_minutes": self.duration_minutes,
            "source": self.source, "is_completed": self.is_completed,
        }


class RagDocument(db.Model):
    __tablename__ = "rag_documents"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    filename = db.Column(db.String(255), nullable=False)
    storage_key = db.Column(db.String(80), nullable=False, unique=True)
    status = db.Column(db.String(20), nullable=False, default="processing", index=True)
    chunk_count = db.Column(db.Integer, nullable=False, default=0)
    error_message = db.Column(db.String(500), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    chunks = db.relationship("RagChunk", back_populates="document", cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id, "filename": self.filename, "status": self.status,
            "chunk_count": self.chunk_count,
            "created_at": self.created_at.isoformat(), "error": self.error_message,
        }


class RagChunk(db.Model):
    __tablename__ = "rag_chunks"
    __table_args__ = (UniqueConstraint("document_id", "chunk_index", name="uq_rag_document_chunk"),)

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    document_id = db.Column(db.Integer, db.ForeignKey("rag_documents.id", ondelete="CASCADE"), nullable=False, index=True)
    chunk_index = db.Column(db.Integer, nullable=False)
    page_number = db.Column(db.Integer, nullable=False)
    content = db.Column(db.Text, nullable=False)
    embedding = db.Column(db.LargeBinary, nullable=False)
    document = db.relationship("RagDocument", back_populates="chunks")


class Conversation(db.Model):
    __tablename__ = "conversations"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=True, index=True)
    title = db.Column(db.String(200), nullable=False, default="New conversation")
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)
    messages = db.relationship(
        "Message", back_populates="conversation", cascade="all, delete-orphan",
        order_by="Message.created_at, Message.id",
    )
    user = db.relationship("User", back_populates="conversations")

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }


class Message(db.Model):
    __tablename__ = "messages"

    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(
        db.Integer, db.ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    role = db.Column(db.String(20), nullable=False)
    content = db.Column(db.Text, nullable=False, default="")
    is_complete = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    conversation = db.relationship("Conversation", back_populates="messages")

    def to_dict(self):
        return {
            "id": self.id,
            "conversation_id": self.conversation_id,
            "role": self.role,
            "content": self.content,
            "is_complete": self.is_complete,
            "created_at": self.created_at.isoformat(),
        }
